#include <gtk/gtk.h>

#include "global.h"
#include "utils.h"

// Update the reassign spectrogram window
void updateReassignSpectrogramWindow(GtkWidget* widget, cairo_t* cr, XSPECTRO* spectro, SMousePos* mousePos);
// Draw the reassign spectrogram
void drawReassignSpectrogram(GtkWidget* widget, cairo_t* cr, XSPECTRO* spectro, SMousePos* mousePos);
// Get the starting ms
float reassignSpectrogramGetStartingMs();
// Set the starting ms
void reassignSpectrogramSetStartingMs(float startMs);
// Draw the reassign spectrogram window grid
void reassignSpectrogramDrawGrid(GtkWidget* widget, cairo_t* cr, XSPECTRO* spectro, SMousePos* mousePos);
// Draw the cursor position information for reasign spectrogram window
void reassignSpectrogramDrawCursorInformation(GtkWidget* widget, cairo_t* cr, XSPECTRO* spectro, SMousePos* mousePos);