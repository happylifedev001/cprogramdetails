#include <gtk/gtk.h>

#include "global.h"
#include "utils.h"

// Update the spectrogram window
void updateSpectrogramWindow(GtkWidget* widget, cairo_t* cr, XSPECTRO* spectro, SMousePos* mousePos);
// Draw the spectrogram
void drawSpectrogram(GtkWidget* widget, cairo_t* cr, XSPECTRO* spectro, SMousePos* mousePos);
// Set the starting ms
void spectrogramSetStartingMs(float startMs);
// Get the starting ms
float spectrogramGetStartingMs();
// Draw the grid
void drawGrid(GtkWidget* widget, cairo_t* cr, XSPECTRO* spectro, SMousePos* mousePos);
// Draw the cursor position information
void drawCursorInformation(GtkWidget* widget, cairo_t* cr, XSPECTRO* spectro, SMousePos* mousePos);