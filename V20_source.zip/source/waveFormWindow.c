#include "waveFormWindow.h"
#include "draw.h"
#include "constants.h"

// Update the wave form window
void updateWaveFormWindow(GtkWidget* widget, cairo_t* cr, SWaveData * waveData, XSPECTRO * spectro, SMousePos * mousePos){

    int _i;
    char _chDatas[255];

    GtkAllocation _allocation;
    gtk_widget_get_allocation(widget, &_allocation);

    float _cx0 = (float)_allocation.x;
    float _cy0 = (float)_allocation.y;

    float _mouseX = mousePos->x - _cx0;
    float _mouseY = mousePos->y - _cy0;

    float _width0 = (float)_allocation.width;
    float _height0 = (float)_allocation.height;

    cairo_set_source_rgb(cr, 0, 0, 0);  // Set color to black
    cairo_set_line_width(cr, 1);
    float _x2[2], _y2[2];

    int _frames = waveData->frames;
    float* _pDatas = waveData->datas;
    float _timeLen = (float)_frames / waveData->sampleRate * 1000; // unit is a ms
    float _msFrame = _timeLen / _frames;
    float _blankX = 50;
    float _blankY = 50;
    float _width = _width0 - _blankX * 2;
    float _width2 = _width / 2;
    float _height = _height0 - _blankY * 2;
    float _height2 = _height / 2;
    float _x0 = _blankX;
    float _y0 = _blankY;

    SWndInfo _wndInfo;

    _wndInfo.x0 = _x0;
    _wndInfo.y0 = _y0;
    _wndInfo.width = _width;
    _wndInfo.height = _height;
    _wndInfo.mouseX = _mouseX;
    _wndInfo.mouseY = _mouseY;
    _wndInfo.cr = cr;

    // Calculate scaling factor for time axis
    float _timeScalingFactor = (float)_width / (float)_timeLen;

    float _coefY = _height2 / 6000.0f;

    // Draw a coordinate
    float _stepTime = 100;
    int _scaleXCount = (int)(_timeLen / _stepTime);
    cairo_set_source_rgb(cr, 0, 0, 0);
    // Draw a region for data
    cairo_set_line_width(cr, 2);

    drawRectangle(cr, _x0, _y0, _width, _height);

    cairo_set_font_size(cr, 14);
    cairo_set_line_width(cr, 2);
    for (_i = 0; _i < _scaleXCount; _i++) {

        float _time = (_i + 1) * _stepTime;
        _x2[0] = _x0 + _time * _timeScalingFactor;
        _y2[0] = _y0 + _height - 20;

        _x2[1] = _x2[0];
        _y2[1] = _y0 + _height;

        cairo_move_to(cr, _x2[0], _y2[0]);
        cairo_line_to(cr, _x2[1], _y2[1]);
        cairo_stroke(cr);

        _x2[0] -= 15;
        _y2[0] = _y0 + _height + 25;
        cairo_move_to(cr, _x2[0], _y2[0]);

#ifdef SAS_VS2022
        sprintf_s(_chDatas, 255, "%.0f", _time);
#else
        sprintf(_chDatas, "%.0f", _time);
#endif

        cairo_show_text(cr, _chDatas);
    }

    // Draw the Y Coordinate
    short _stepValue = 2000;
    int _scaleYCount = 6000 / _stepValue;
    for (_i = 0; _i < _scaleYCount - 1; _i++) {

        short _value = (_i + 1) * _stepValue;
        _x2[0] = _x0;
        _y2[0] = _y0 + _height2 - (float)_value * _coefY;

        _x2[1] = _x0 + 20;
        _y2[1] = _y2[0];

        drawLine(cr, _x2[0], _y2[0], _x2[1], _y2[1]);

        _x2[0] -= 40;
        _y2[0] += 5;
        cairo_move_to(cr, _x2[0], _y2[0]);

#ifdef SAS_VS2022
        sprintf_s(_chDatas, 255, "%d", _value);
#else
        sprintf(_chDatas, "%d", _value);
#endif

        cairo_show_text(cr, _chDatas);
    }

    for (_i = 0; _i < _scaleYCount - 1; _i++) {

        short _value = -(_i + 1) * _stepValue;
        _x2[0] = _x0;
        _y2[0] = _y0 + _height2 - (float)_value * _coefY;

        _x2[1] = _x0 + 20;
        _y2[1] = _y2[0];

        drawLine(cr, _x2[0], _y2[0], _x2[1], _y2[1]);

        _x2[0] -= 40;
        _y2[0] += 5;
        cairo_move_to(cr, _x2[0], _y2[0]);

#ifdef SAS_VS2022
        sprintf_s(_chDatas, 255, "%d", _value);
#else
        sprintf(_chDatas, "%d", _value);
#endif
        cairo_show_text(cr, _chDatas);
    }

    cairo_set_source_rgb(cr, 0, 0, 0);
    cairo_set_line_width(cr, 2);

    // Draw X-axis
    drawLine(cr, _x0, _y0 + _height2, _x0 + _width, _y0 + _height2);

    // Draw Y-axis
    drawLine(cr, _x0 + _width2, _y0, _x0 + _width2, _y0 + _height);

    if (waveData->datas == NULL
        || waveData->channels < 1 || waveData->frames < 1
        || !waveData->isData)
        return;

    // Draw the wave form curve
    drawWaveformCurve(&_wndInfo, spectro);

    // Draw a focus information
    drawWaveformFocusInfo(&_wndInfo, spectro);

    // Draw the cursor position info
    drawWaveformCursorInfo(&_wndInfo, spectro);
}

// Draw the waveform focus info
void drawWaveformFocusInfo(SWndInfo* wndInfo, XSPECTRO* spectro) {

    char _chDatas[255];

    float _x0 = wndInfo->x0;
    float _y0 = wndInfo->y0;
    float _width = wndInfo->width;
    float _height = wndInfo->height;
    float _mouseX = wndInfo->mouseX;
    float _mouseY = wndInfo->mouseY;
    float _height2 = _height / 2.0f;

    int _frames = spectro->totsamp;
    cairo_t* _cr = wndInfo->cr;

    float _timeLen = (float)_frames / spectro->spers * 1000; // unit is a ms
    float _msFrame = _timeLen / _frames;

    // Calculate scaling factor for time axis
    float _timeScalingFactor = (float)_width / (float)_timeLen;

    float _coefX = _width / _timeLen;
    float _coefY = _height2 / 6000.0f;

    float _time = spectro->savetime;

    float _x = _x0 + _time * _coefX;
    int _dataPos = (int)(_time / _msFrame + 0.5f);

    if (_dataPos < 0)
        _dataPos = 0;
    if (_dataPos >= _frames)
        _dataPos = _frames - 1;

    cairo_set_source_rgb( _cr, 1.00, 0, 0);  // Set color to red
    cairo_set_line_width( _cr, 1);

    drawLine( _cr, _x, _y0, _x, _y0 + _height);

    short _sData = spectro->iwave[_dataPos];
    float _data = (float)_sData;
    _data *= g_cWaveDataCoef;

    float _y = _y0 + _height2 - _data * _coefY;

#ifdef SAS_VS2022
    sprintf_s(_chDatas, 255, "%.2fms(%.1f)", _time, _data);
#else
    sprintf(_chDatas, "%.2fms(%.1f)", _time, _data);
#endif

    cairo_set_source_rgb( _cr, 1.0, 0, 0);  // Set color to red

    drawRectangle( _cr, _x - 2, _y - 2, 5, 5);

    cairo_set_font_size( _cr, 14);
    cairo_move_to( _cr, _x, _y0 - 20.0f);
    cairo_show_text( _cr, _chDatas);

    double _dashes[] = { 2.0, 2.0 };
    int _ndash = sizeof(_dashes) / sizeof(_dashes[0]);

    // Draw a start marker
    int _index = spectro->startmarker;
    if (_index >= 0) {

        _x = _x0 + _index * _width / _frames;

        cairo_set_dash(_cr, _dashes, _ndash, 0);

        cairo_set_source_rgb(_cr, 0.0, 0, 0);
        cairo_set_line_width(_cr, 1);

        drawLine(_cr, _x, _y0, _x, _y0 + _height);

#ifdef SAS_VS2022
        sprintf_s(_chDatas, 255, "w");
#else
        sprintf(_chDatas, "w");
#endif

        cairo_set_font_size(_cr, 14);
        cairo_move_to(_cr, _x - 5, _y0 - 8);
        cairo_show_text(_cr, _chDatas);
    }

    // Draw a end marker
    _index = spectro->endmarker;

    if (_index >= 0) {

        _x = _x0 + _index * _width / _frames;

        cairo_set_source_rgb(_cr, 0.0, 0, 0);
        cairo_set_line_width(_cr, 1);

        drawLine(_cr, _x, _y0, _x, _y0 + _height);

#ifdef SAS_VS2022
        sprintf_s(_chDatas, 255, "e");
#else
        sprintf(_chDatas, "e");
#endif

        cairo_set_font_size(_cr, 14);
        cairo_move_to(_cr, _x - 5, _y0 - 8);
        cairo_show_text(_cr, _chDatas);
    }

    cairo_set_dash(_cr, NULL, 0, 0);
}

// Draw the waveform cursor info
void drawWaveformCursorInfo(SWndInfo* wndInfo, XSPECTRO* spectro) {

    char _chDatas[255];

    float _x0 = wndInfo->x0;
    float _y0 = wndInfo->y0;
    float _width = wndInfo->width;
    float _height = wndInfo->height;
    float _mouseX = wndInfo->mouseX;
    float _mouseY = wndInfo->mouseY;
    float _height2 = _height / 2.0f;

    int _frames = spectro->totsamp;
    cairo_t* _cr = wndInfo->cr;

    float _timeLen = (float)_frames / spectro->spers * 1000; // unit is a ms
    float _msFrame = _timeLen / _frames;

    // Calculate scaling factor for time axis
    float _timeScalingFactor = (float)_width / (float)_timeLen;

    float _coefY = _height2 / 6000.0f;

    if (_mouseX > _x0 && _mouseY > _y0
        && _mouseX < _x0 + _width && _mouseY < _y0 + _height) {

        float _time = (_mouseX - _x0) * _timeLen / _width;

        int _dataPos = (int)((float)_frames * (_mouseX - _x0) / _width);

        if (_dataPos < 0)
            _dataPos = 0;

        if (_dataPos >= _frames)
            _dataPos = _frames - 1;

        cairo_set_source_rgb( _cr, 0, 0, 1.0);  // Set color to blue
        cairo_set_line_width( _cr, 1);

        double _dashes[] = { 2.0, 2.0 };
        int _ndash = sizeof(_dashes) / sizeof(_dashes[0]);
        cairo_set_dash(_cr, _dashes, _ndash, 0);

        float _x = _mouseX;

        drawLine( _cr, _x, _y0, _x, _y0 + _height);

        cairo_set_dash(_cr, NULL, 0, 0);

        short _sData = spectro->iwave[_dataPos];
        float _data = (float)_sData;
        _data *= g_cWaveDataCoef;

        float _y = _y0 + _height2 - _data * _coefY;

#ifdef SAS_VS2022
        sprintf_s(_chDatas, 255, "%.2fms(%.1f)", _time, _data);
#else
        sprintf(_chDatas, "%.2fms(%.1f)", _time, _data);
#endif

        cairo_set_source_rgb( _cr, 0, 0, 1.0);  // Set color to blue

        drawRectangle( _cr, _x - 2, _y - 2, 5, 5);

        cairo_set_font_size( _cr, 14);
        cairo_move_to( _cr, _x, _y0 - 20.0f);
        cairo_show_text( _cr, _chDatas);
    }
}

// Draw the wave form curve
void drawWaveformCurve(SWndInfo* wndInfo, XSPECTRO* spectro) {

    int _i;

    float _x0 = wndInfo->x0;
    float _y0 = wndInfo->y0;
    float _width = wndInfo->width;
    float _height = wndInfo->height;
    float _height2 = _height / 2.0f;

    float _preX, _preY, _x, _y;

    int _frames = spectro->totsamp;
    cairo_t* _cr = wndInfo->cr;

    float _timeLen = (float)_frames / spectro->spers * 1000; // unit is a ms
    float _msFrame = _timeLen / _frames;

    // Calculate scaling factor for time axis
    float _timeScalingFactor = (float)_width / (float)_timeLen;

    float _coefY = _height2 / 6000.0f;

    cairo_set_source_rgb( _cr, 0, 0, 0);  // Set color to black
    cairo_set_line_width( _cr, 1);

    _x = 0.0f;
    _y = 0.0f;
    for (_i = 0; _i < _frames; _i++) {

        _preX = _x;
        _preY = _y;

        short _sData = spectro->iwave[_i];
        float _data = (float)_sData;
        _data *= g_cWaveDataCoef;

        float _time = (_i + 1) * _msFrame;

        _x = _x0 + _time * _timeScalingFactor;
        _y = _y0 + _height2 - _data * _coefY;

        if (_i > 0)
            drawLine( _cr, _preX, _preY, _x, _y);
    }
}
