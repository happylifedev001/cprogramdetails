#ifndef __CONSTANTS_H__
#define __CONSTANTS_H__

extern const float g_cWaveDataCoef;

#endif